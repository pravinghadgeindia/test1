﻿namespace General
{ 
    public static class CommonFields
    {
        public const string DocEntry = "DocEntry";
        public const string DocDate= "DocDate";
        public const string Code = "Code";
        public const string Name = "Name";
        public const string LineId = "LineId";
        public const string LineNum = "LineNum";

        public const string ObjType = "ObjType";

        /* BusinessPartnerCards */
        public const string CardCode = "CardCode";
        public const string CardName = "CardName";

        /* Item Master */
        public const string ItemCode = "ItemCode";
        public const string ItemName = "ItemName";

        /* Warehouse Master */
        public const string WhsCode = "WhsCode";
        public const string WhsName = "WhsName";
    }
}
 