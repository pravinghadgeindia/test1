using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace General
{
    class clsDelOrder : Connection
    {
        #region Variables

        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.DataTable oDataTable;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Grid grd1;
        string grdUID = "grd1";
        string grdDataTableUID = "grdDataTable";
        string grdCheckBoxUID = "chk";
        string xmlFileName = "BOMList";
        string formUID = "BOMList";
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                            #region Select All
                            if (pVal.ItemUID == "btnSelAll")
                            {
                                FillGrid(YesNoEnum.Y.ToString());
                            }
                            #endregion

                            #region DeSelect All
                            else if (pVal.ItemUID == "btnDSelAll")
                            {
                                FillGrid(YesNoEnum.N.ToString());
                            }
                            #endregion

                            #region DeSelect All
                            else if (pVal.ItemUID == "btnCopy")
                            {
                                SAPbouiCOM.Form oBaseForm = (SAPbouiCOM.Form)oApplication.Forms.Item(clsVariables.BaseFormUID);
                                SAPbouiCOM.Matrix oBaseFormMatrix = (SAPbouiCOM.Matrix)oBaseForm.Items.Item("38").Specific;

                                oApplication.StatusBar.SetText("Setting Data To Matrix....", BoMessageTime.bmt_Long, BoStatusBarMessageType.smt_Success);
                                oDataTable = oForm.DataSources.DataTables.Item(grdDataTableUID);
                                #region Setting Data to Matrix
                                for (int i = 0; i < oDataTable.Rows.Count; i++)
                                {
                                    if (oDataTable.GetValue(grdCheckBoxUID, i).ToString() == YesNoEnum.Y.ToString())
                                    {
                                        ((SAPbouiCOM.EditText)oBaseFormMatrix.GetCellSpecific("1", i + 1)).String = oDataTable.GetValue("Child ItemCode", i).ToString();
                                    }
                                }
                                #endregion
                                oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel)).Click(BoCellClickType.ct_Regular);
                                oApplication.StatusBar.SetText("Operation completed.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                            }
                            #endregion
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Selection Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Selection Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        #endregion

        #region

        public void LoadForm()
        {
            objclsComman.LoadXML(xmlFileName, "", "", BoFormMode.fm_OK_MODE);
            FillGrid(YesNoEnum.N.ToString());
        }

        private void FillGrid(string chkValue)
        {
            //oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(formUID);
            oForm = oApplication.Forms.ActiveForm;
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.Code [Parent ItemCode],T2.ItemName [Parent ItemName],");
            sbQuery.Append(" T1.Code [Child ItemCode],T2.ItemName [Child ItemName],T1.Quantity,'" + chkValue + "' " + grdCheckBoxUID + "");
            sbQuery.Append(" FROM OITT T0");
            sbQuery.Append(" INNER JOIN ITT1 T1 ON T0.Code = T1.Father");
            sbQuery.Append(" INNER JOIN OITM T2 ON T0.Code = T2.ItemCode");
            sbQuery.Append(" INNER JOIN OITM T3 ON T1.Code = T3.ItemCode");
            grd1 = (SAPbouiCOM.Grid)oForm.Items.Item(grdUID).Specific;
            oForm.Freeze(true);
            objclsComman.FillGrid(oForm.UniqueID, grdUID, grdDataTableUID, sbQuery.ToString(), 1);
            grd1.Columns.Item(grdCheckBoxUID).Type = BoGridColumnType.gct_CheckBox;
            oForm.Freeze(false);
        }
        #endregion
    }
}
