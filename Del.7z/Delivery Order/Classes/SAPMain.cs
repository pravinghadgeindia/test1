using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using SAPbouiCOM;
using System;
using System.Reflection;

namespace General
{
    class SAPMain : Connection
    {
        public static ILog logger;

        #region Variables

        clsCommon objclsComman = new clsCommon();
        SAPbouiCOM.Form oForm;
        clsDelOrder objclsDelOrder = new clsDelOrder();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();

            // Get reference to the Center form
            oForm = oApplication.Forms.GetFormByTypeAndCount(((int)SAPFormUIDEnum.MainMenu), 1);

            oForm.Freeze(true);
            PrepareMenus();
            oForm.Freeze(false);
            oForm.Update();
            PrepareEvents();
        }


        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", nameof(PrepareMenus));
            string superUser = objclsComman.SelectRecord("SELECT SUPERUSER FROM OUSR WHERE USERID='" + oCompany.UserSignature + "'");
            if (superUser == YesNoEnum.Y.ToString())
            {
                objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.UDO.ToString(), "Create Delivery Order UDO", 0);
            }

            objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SalesAR), SAPCustomFormUIDEnum.DELORDER.ToString(), "Delivery Order Status", 5);
        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", nameof(PrepareEvents));
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new SAPbouiCOM._IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
        }


        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch
                {

                }

                if (pVal.FormTypeEx == SAPCustomFormUIDEnum.DELORDER.ToString())
                {
                    objclsDelOrder.ItemEvent(ref pVal, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                logger.Error(this.GetType().Name + " > Item Event " + ex.Message);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }

                if (pVal.MenuUID == SAPCustomFormUIDEnum.UDO.ToString())
                {
                    if (pVal.BeforeAction == true)
                    {
                        objclsComman.CreateDataBase();
                        oApplication.StatusBar.SetText("Object Tables Created successfully !", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Success);
                    }
                }

                if (pVal.MenuUID == SAPCustomFormUIDEnum.DELORDER.ToString() || oForm.TypeEx == SAPCustomFormUIDEnum.DELORDER.ToString())
                {
                    objclsDelOrder.MenuEvent(ref pVal, out BubbleEvent);
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > Menu Event " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                logger.Error(this.GetType().Name + " > Menu Event " + ex.Message);
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (BusinessObjectInfo.FormTypeEx== SAPCustomFormUIDEnum.DELORDER.ToString())
            {
                objclsDelOrder.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            string projAssemlbly = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(projAssemlbly + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(projAssemlbly + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(projAssemlbly + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(projAssemlbly + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
