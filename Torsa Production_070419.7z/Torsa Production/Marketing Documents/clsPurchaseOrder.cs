using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;

namespace Torsa_Production
{
    class clsPurchaseOrder : Connection
    {
        #region Variables

        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        string headerTable = "OPOR";
        string childTable = "POR1";
        string formTitle = "Purchase Order";
        string matrixUID = "38";
        string itemCodeColUID = "1";
        string copyFromBOMCaption = "Copy From BOM";
        string copyFromBOMUID = "btnCopy";

        //string formId = "Checking";
        //string objectId = "Checking";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true -> Before SAP Events
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                ArrayList al = new ArrayList();
                                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                                {
                                    string itemcode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific(itemCodeColUID, i)).String.Trim();
                                    if (itemcode != string.Empty)
                                    {
                                        string itemType = objclsComman.SelectRecord("SELECT TreeType from OITM WHERE ItemCode='" + itemcode + "'");
                                        if (itemType == "P")
                                        {
                                            al.Add(i.ToString());
                                        }
                                    }
                                }

                                if (al != null)
                                {
                                    string rowNo = String.Join(",", al.ToArray());
                                    int k = oApplication.MessageBox("There are BOM items at Row No: " + rowNo + ". Do you really want to proceed? ", 1, "Yes", "No", "");
                                    if (k != 1)
                                    {
                                        BubbleEvent = false;
                                        return;
                                    }
                                }
                            }

                            else if (pVal.ItemUID == copyFromBOMUID)
                            {
                                string cardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(SAPCommonFieldEnum.CardCode.ToString(), 0).Trim();
                                if (cardCode == string.Empty)
                                {
                                    oApplication.StatusBar.SetText("Please select supplier.", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Warning);
                                    return;
                                }
                                clsVariables.BaseFormUID = pVal.FormUID;
                                clsBOMList objclsBOMList = new clsBOMList();
                                objclsBOMList.LoadForm();
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false -> After SAP Events
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.Item oNewItem = oForm.Items.Add(copyFromBOMUID, SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                            //oItem is an existing button, which I refer to use the 'top, left coordenates and size. Change to the proper ID
                            oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                            oNewItem.Left = oItem.Left + oItem.Width + 10;
                            oNewItem.Top = oItem.Top;
                            oNewItem.Height = oItem.Height;
                            oNewItem.Width = oItem.Width + 30;

                            SAPbouiCOM.Button obtn = (SAPbouiCOM.Button)oNewItem.Specific;
                            obtn.Caption = copyFromBOMCaption;
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }


        #endregion

    }
}
