using System;
using System.Collections.Generic;
using System.Text;
using SAPbobsCOM;
using System.Data.SqlClient;
using System.Data;
using System.Collections;

namespace General
{
    class clsCommon : Connection
    {
        #region Variables

        private SAPbobsCOM.UserTablesMD oUserTablesMD = null;
        private SAPbobsCOM.UserFieldsMD oUserFieldsMD = null;
        private SAPbobsCOM.UserObjectsMD oUserObjectMD = null;

        private SAPbouiCOM.Item oItem;
        public int SerNo = 0;
        public string Series = "";
        public string SerName = "";
        public SAPbouiCOM.ChooseFromList oCFL = null;
        public SAPbouiCOM.ChooseFromListCollection oCFLs = null;
        public SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
        public SAPbouiCOM.Conditions oCons = null;
        public SAPbouiCOM.Condition oCon = null;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbobsCOM.Recordset oRs;
        #endregion

        #region Constructor
        public clsCommon()
        {
            //  Utility();
        }
        #endregion

        #region Methods

        #region AddMenu

        public void AddMenu(SAPbouiCOM.BoMenuType boMenuType, string FatherID, string UniqueID, string Name, int Position)
        {
            try
            {
                SAPbouiCOM.Menus oMenus = null;
                SAPbouiCOM.MenuItem oMenuItem = null;

                oMenus = oApplication.Menus;

                SAPbouiCOM.MenuCreationParams oCreationPackage = null;
                oCreationPackage = ((SAPbouiCOM.MenuCreationParams)oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_MenuCreationParams));
                oMenuItem = oApplication.Menus.Item(FatherID);
                oCreationPackage.Type = boMenuType;
                oCreationPackage.UniqueID = UniqueID;
                oCreationPackage.String = Name;
                oCreationPackage.Position = Position;
                oCreationPackage.Enabled = true;
                oMenus = oMenuItem.SubMenus;
                if (oMenus.Exists(UniqueID) == false)
                    oMenus.AddEx(oCreationPackage);
            }
            catch { }
        }

        #endregion

        #region Database

        public bool CreateDataBase()
        {
            try
            {
                Main.logger.DebugFormat("> {0}", nameof(CreateDataBase));

                oApplication.StatusBar.SetText("Please Wait....", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                CreateTables();
                //CreateUserObject("PROD_OIGE", "Multiple Issue for Production", "PROD_OIGE", "PROD_IGE1", "", "", false);
                //CreateUserObject("PROD_OIGN", "Multiple Receipt from Production", "PROD_OIGN", "PROD_IGN1", "", "", false);
                //CreateUserObjectMASTER("HEATMSTR", "Heat Master", "HEATMSTR", "", "", "", false);


                //CreateUserObject("CS_PRDREC", "CostSheet Prod Recording", "CS_PRDREC", "CS_PRDREC1", "", "", false);
                CreateFields();
                return true;
            }
            catch (Exception ex)
            {
                oApplication.MessageBox(ex.Message.ToString(), 1, "ok", "", "");
                return false;
            }
        }

        public Boolean FieldDetails(string TableName, string FieldName, string FieldDesc, UDFFieldType FieldType, bool Mandatory, int FieldSize, string DefaultVal, string LinkedTable, string LinkedUDO)
        {
            string ErrMsg;
            int errCode;
            int IRetCode;
            oUserFieldsMD = null;
            SAPbobsCOM.Recordset oRecordSet = null;

            try
            {
                oRecordSet = (SAPbobsCOM.Recordset)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                string sqlQuery = string.Format("SELECT T0.TableID, T0.FieldID FROM CUFD T0 WHERE T0.TableID = '@{0}' AND T0.AliasID = '{1}'", TableName, FieldName);
                oRecordSet.DoQuery(sqlQuery);

                bool retflag = false;

                if (oRecordSet.RecordCount == 1)
                {
                    retflag = true;
                }

                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRecordSet);
                oRecordSet = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();

                if (retflag == true) return true;

                if (oUserFieldsMD == null)
                {
                    oUserFieldsMD = ((SAPbobsCOM.UserFieldsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)));
                }
                oUserFieldsMD.TableName = TableName;
                oUserFieldsMD.Name = FieldName;
                oUserFieldsMD.Description = FieldDesc;
                switch (FieldType)
                {
                    case UDFFieldType.Alpha:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;
                        if (LinkedTable != string.Empty)
                        {
                            oUserFieldsMD.LinkedTable = LinkedTable;
                        }
                        if (LinkedUDO != string.Empty)
                        {
                            oUserFieldsMD.LinkedUDO = LinkedUDO;
                        }
                        break;
                    case UDFFieldType.Text:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo; // alphanumeric type                   
                        // oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case UDFFieldType.Integer:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Numeric; //  Integer type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;
                    case UDFFieldType.Date:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date; // Date type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_None;
                        break;

                    case UDFFieldType.Time:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Date; // Time type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Time;
                        break;

                    case UDFFieldType.Amount:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Sum; // Amount type
                        break;
                    case UDFFieldType.Quantity:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Quantity; // Amount type
                        break;
                    case UDFFieldType.Percent:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Percentage; // Amount type
                        break;
                    case UDFFieldType.UnitTotal:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float; // Amount type
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Measurement; // Amount type
                        break;

                    case UDFFieldType.YN:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Alpha; // alphanumeric type                   
                        oUserFieldsMD.EditSize = FieldSize;

                        oUserFieldsMD.ValidValues.Value = "Y";
                        oUserFieldsMD.ValidValues.Description = "Y";
                        oUserFieldsMD.ValidValues.Add();

                        oUserFieldsMD.ValidValues.Value = "N";
                        oUserFieldsMD.ValidValues.Description = "N";
                        oUserFieldsMD.ValidValues.Add();

                        break;

                    case UDFFieldType.Rate:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Rate;
                        break;

                    case UDFFieldType.Price:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Float;
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Price;
                        break;

                    case UDFFieldType.Link:
                        oUserFieldsMD.Type = SAPbobsCOM.BoFieldTypes.db_Memo; // alphanumeric type 
                        oUserFieldsMD.SubType = SAPbobsCOM.BoFldSubTypes.st_Link;
                        oUserFieldsMD.EditSize = FieldSize;
                        break;

                }
                //if (Mandatory)
                //{
                //    oUserFieldsMD.Mandatory = SAPbobsCOM.BoYesNoEnum.tYES;

                //}
                if (DefaultVal != "")
                {
                    oUserFieldsMD.DefaultValue = DefaultVal;

                }

                // Add the field to the table
                IRetCode = oUserFieldsMD.Add();
                if (IRetCode != 0)
                {
                    oCompany.GetLastError(out errCode, out ErrMsg);
                }
                return true;
            }
            finally
            {
                if (oUserFieldsMD != null)
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldsMD);

                oUserFieldsMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                //return false ;
            }
        }

        public Boolean CreateFields()
        {
            try
            {
                FieldDetails("DelOrder", "FrDate", "From Date", UDFFieldType.Date, false, 1, string.Empty,string.Empty, string.Empty);
                FieldDetails("DelOrder", "ToDate", "To Date", UDFFieldType.Date, false, 1, string.Empty, string.Empty, string.Empty);
                FieldDetails("DelOrder", "FrBPCode", "From BP Code", UDFFieldType.Alpha, false, 40, string.Empty, string.Empty, string.Empty);
                FieldDetails("DelOrder", "ToBPCode", "To BP Code", UDFFieldType.Alpha, false, 40, string.Empty, string.Empty, string.Empty);
                //FieldDetails("DelOrder", "FrBPName", "From BP Code", UDFFieldType.Alpha, false, 40, string.Empty, string.Empty, string.Empty);
                //FieldDetails("DelOrder", "ToBPN", "To BP Code", UDFFieldType.Alpha, false, 40, string.Empty, string.Empty, string.Empty);

                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateTables()
        {
            try
            {
                CreateTable("DelOrder", "Delivery Order Status", "Document");
                CreateTable("DelOrder1", "Delivery Order Status-Rows", "DocLine");
                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateTable(string TableName, string TableDesc, string TableType)
        {
            try
            {
                oUserTablesMD = null;
                if (oUserTablesMD == null)
                {
                    oUserTablesMD = ((SAPbobsCOM.UserTablesMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables)));
                }
                if (oUserTablesMD.GetByKey(TableName) == true)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    return true;
                }
                oUserTablesMD.TableName = TableName;
                oUserTablesMD.TableDescription = TableDesc;
                if (TableType == "Master")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterData;
                }
                else if (TableType == "Child")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_MasterDataLines;
                }
                else if (TableType == "Document")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_Document;
                }
                else if (TableType == "DocLine")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_DocumentLines;
                }
                else if (TableType == "Object")
                {
                    oUserTablesMD.TableType = SAPbobsCOM.BoUTBTableType.bott_NoObject;
                }
                int err = oUserTablesMD.Add();
                string errMsg = "";
                oCompany.GetLastError(out err, out errMsg);
                if (err == 0)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                else
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD);
                    oUserTablesMD = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                return true;
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Create Table: " + TableName + " " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return false;
            }
        }

        private Boolean CreateUserObjectMASTER(string CodeID, string Name, string TableName, string Child, string Child1, string Child2, Boolean DefaultForm)
        {
            int lRetCode = 0;
            string sErrMsg = null;
            oUserObjectMD = null;
            if (oUserObjectMD == null)
                oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

            if (oUserObjectMD.GetByKey(CodeID) == true)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
                oUserObjectMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                return true;
            }

            oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.Code = CodeID;
            oUserObjectMD.Name = Name;

            oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.FindColumns.SetCurrentLine(0);
            oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_MasterData;
            oUserObjectMD.FindColumns.ColumnAlias = "Code";
            oUserObjectMD.FindColumns.ColumnDescription = "Code";
            oUserObjectMD.FindColumns.Add();
            //oUserObjectMD.FindColumns.SetCurrentLine(1);
            //oUserObjectMD.FindColumns.ColumnAlias = "DocNum";
            //oUserObjectMD.FindColumns.ColumnDescription = "Doc Num";
            //oUserObjectMD.FindColumns.Add();


            oUserObjectMD.TableName = TableName;

            if (Child != "")
            {
                oUserObjectMD.ChildTables.TableName = Child;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child1 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child1;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child2 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child2;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (DefaultForm == true)
            {
                oUserObjectMD.CanCreateDefaultForm = BoYesNoEnum.tYES;
            }

            lRetCode = oUserObjectMD.Add();

            // check for errors in the process
            if (lRetCode != 0)
                if (lRetCode == -1)
                { }
                else
                { oCompany.GetLastError(out lRetCode, out sErrMsg); }
            else
            { }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
            oUserObjectMD = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }

        private Boolean CreateUserObject(string CodeID, string Name, string TableName, string Child, string Child1, string Child2, Boolean DefaultForm)
        {
            int lRetCode = 0;
            string sErrMsg = null;
            oUserObjectMD = null;
            if (oUserObjectMD == null)
                oUserObjectMD = ((SAPbobsCOM.UserObjectsMD)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)));

            if (oUserObjectMD.GetByKey(CodeID) == true)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
                oUserObjectMD = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
                return true;
            }

            oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
            oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.Code = CodeID;
            oUserObjectMD.Name = Name;

            oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;

            oUserObjectMD.FindColumns.SetCurrentLine(0);
            oUserObjectMD.ObjectType = SAPbobsCOM.BoUDOObjType.boud_Document;
            oUserObjectMD.FindColumns.ColumnAlias = "DocEntry";
            oUserObjectMD.FindColumns.ColumnDescription = "DocEntry";
            oUserObjectMD.FindColumns.Add();
            oUserObjectMD.FindColumns.SetCurrentLine(1);
            oUserObjectMD.FindColumns.ColumnAlias = "DocNum";
            oUserObjectMD.FindColumns.ColumnDescription = "Doc Num";
            oUserObjectMD.FindColumns.Add();


            oUserObjectMD.TableName = TableName;

            if (Child != "")
            {
                oUserObjectMD.ChildTables.TableName = Child;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child1 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child1;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (Child2 != "")
            {
                oUserObjectMD.ChildTables.Add();
                oUserObjectMD.ChildTables.TableName = Child2;
                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
            }
            if (DefaultForm == true)
            {
                oUserObjectMD.CanCreateDefaultForm = BoYesNoEnum.tYES;
            }

            lRetCode = oUserObjectMD.Add();

            // check for errors in the process
            if (lRetCode != 0)
                if (lRetCode == -1)
                { }
                else
                { oCompany.GetLastError(out lRetCode, out sErrMsg); }
            else
            { }

            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD);
            oUserObjectMD = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            return true;
        }

        #endregion

        #region Load Forms

        public void LoadXML(string XMLFile, string BrowseBy, string Title, SAPbouiCOM.BoFormMode boFormMode)
        {

            try
            {
                System.Xml.XmlDocument xmldoc = new System.Xml.XmlDocument();
                string file = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ".XMLForms." + XMLFile + ".xml";
                System.IO.Stream Streaming = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(file);
                System.IO.StreamReader StreamRead = new System.IO.StreamReader(Streaming, true);
                xmldoc.LoadXml(StreamRead.ReadToEnd());
                StreamRead.Close();
                Random r = new Random();
                r.Next(1000);

                if ((xmldoc.SelectSingleNode("//form") != null))
                {
                    xmldoc.SelectSingleNode("//form").Attributes.GetNamedItem("uid").Value =
                    xmldoc.SelectSingleNode("//form").Attributes.GetNamedItem("uid").Value.ToString() + "_" + r.Next().ToString();
                    string sXML = xmldoc.InnerXml.ToString();
                    oApplication.LoadBatchActions(ref sXML);

                    oForm = oApplication.Forms.ActiveForm;
                    if (Title != "")
                    {
                        oForm.Title = Title;
                    }
                    oForm.SupportedModes = -1;

                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FindRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FirstRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LastRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.NextRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.PreviousRecord), true);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), false);
                    oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.UDFForm), false);

                    if (BrowseBy != "")
                    {
                        oForm.DataBrowser.BrowseBy = BrowseBy;
                    }
                    oForm.Mode = boFormMode;
                    //if (FormMode == "A")
                    //{
                    //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                    //}
                    //else if (FormMode == "U")
                    //{
                    //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                    //}
                    //else if (FormMode == "F")
                    //{
                    //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                    //}
                    //else if (FormMode == "O")
                    //{
                    //    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE;
                    //}
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void LoadFromXML(string FileName, string BrowseBy, out string FormUID, string Title, string FormMode)
        {
            FormUID = "";
            try
            {

                System.Xml.XmlDocument oXmlDoc = null;
                string sPath = null;
                oXmlDoc = new System.Xml.XmlDocument();

                sPath = System.Windows.Forms.Application.StartupPath + "\\Forms\\" + FileName + ".srf";
                oXmlDoc.Load(sPath);

                string sXML = oXmlDoc.InnerXml.ToString();
                oApplication.LoadBatchActions(ref sXML);

                oForm = oApplication.Forms.ActiveForm;
                FormUID = oForm.UniqueID;
                if (Title != "")
                {
                    oForm.Title = Title;
                }
                oForm.SupportedModes = -1;

                oForm.EnableMenu("1281", true);
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);


                oForm.EnableMenu("1292", true); //Activate Add row menu required for transactions
                oForm.EnableMenu("1293", true); //Activate delete row menu required for transactions
                if (BrowseBy != "")
                {
                    oForm.DataBrowser.BrowseBy = BrowseBy;
                }
                if (FormMode == "A")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                }
                else
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                }

                //return (oXmlDoc.InnerXml);

            }
            catch
            {

            }

        }

        public string LoadFromXML(string FileName, string BrowseBy, string FormMode)
        {
            try
            {
                System.Xml.XmlDocument oXmlDoc = null;
                string sPath = null;
                oXmlDoc = new System.Xml.XmlDocument();
                sPath = System.Windows.Forms.Application.StartupPath + "\\Forms\\" + FileName + ".srf";
                oXmlDoc.Load(sPath);
                string sXML = oXmlDoc.InnerXml.ToString();
                oApplication.LoadBatchActions(ref sXML);
                oForm = oApplication.Forms.Item(FileName);
                oForm.SupportedModes = -1;
                oForm.EnableMenu("1281", true);
                oForm.EnableMenu("1282", true);
                oForm.EnableMenu("1288", true);
                oForm.EnableMenu("1289", true);
                oForm.EnableMenu("1290", true);
                oForm.EnableMenu("1291", true);
                oForm.EnableMenu("1292", true); //Activate Add row menu required for transactions
                oForm.EnableMenu("1293", true); //Activate delete row menu required for transactions
                oForm.EnableMenu("6913", false);

                if (BrowseBy != "")
                {
                    oForm.DataBrowser.BrowseBy = BrowseBy;
                }
                if (FormMode == "A")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                }
                else if (FormMode == "F")
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_FIND_MODE;
                }
                return (oXmlDoc.InnerXml);

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, true);
            }
            return "";
        }

        public void LoadDefaultForm(string udoID)
        {
            SAPbouiCOM.MenuItem menu = oApplication.Menus.Item("47616"); // Link to the Default Forms menu
            try
            {
                if (menu.SubMenus.Count > 0)
                {
                    for (int i = 0; i <= menu.SubMenus.Count - 1; i++)
                    {
                        if (menu.SubMenus.Item(i).String.Contains(udoID))
                        {
                            menu.SubMenus.Item(i).Activate();
                        }

                    }

                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage("ERROR: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Long, true);
            }

        }

        #endregion

        #region AddChooseFromList

        public void AddChooseFromList(SAPbouiCOM.Form oForm, string UniqueID, string CondVal)
        {
            try
            {

                SAPbouiCOM.ChooseFromListCollection oCFLs = null;

                oCFLs = oForm.ChooseFromLists;

                SAPbouiCOM.ChooseFromList oCFL = null;
                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));

                oCFLCreationParams.MultiSelection = false;
                oCFLCreationParams.ObjectType = CondVal;
                oCFLCreationParams.UniqueID = UniqueID;
                oCFL = oCFLs.Add(oCFLCreationParams);
            }
            catch
            {

            }
        }

        public void AddCondOnCFLCodeWise(SAPbouiCOM.Form frmRFQ, string objectid, string query, string Alias, string CondVal)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            SAPbouiCOM.Conditions oCons = null;
            SAPbouiCOM.Condition oCon = null;
            try
            {
                oCFL = frmRFQ.ChooseFromLists.Item(objectid);

                oRs = returnRecord(query);

                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();
                if (query == "")
                {
                    if (oCons.Count > 0) //'If there are already user conditions.
                    {
                        oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;
                    }
                    oCon = oCons.Add();
                    oCon.BracketOpenNum = 1;
                    oCon.Alias = Alias;
                    oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    oCon.CondVal = CondVal;
                    oCon.BracketCloseNum = 1;
                    oCFL.SetConditions(oCons);
                }
                else if (oRs.RecordCount == 0)
                {
                    oCon = oCons.Add();
                    oCon.Alias = Alias;
                    oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    oCon.CondVal = "1";
                    oCFL.SetConditions(oCons);
                }
                else
                {
                    while (!oRs.EoF)
                    {
                        if (oCons.Count > 0) //'If there are already user conditions.
                        {
                            oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                        }
                        oCon = oCons.Add();
                        oCon.Alias = Alias;
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = oRs.Fields.Item(0).Value.ToString();
                        oRs.MoveNext();
                        oCFL.SetConditions(oCons);
                    }
                }

            }
            catch
            {

            }
        }

        public void AddChooseFromList_NoCond(SAPbouiCOM.Form oFormChoose, string cflID, string objectid)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            try
            {
                SAPbouiCOM.ChooseFromListCollection oCFLs = null;
                oCFLs = oFormChoose.ChooseFromLists;
                SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));
                oCFLCreationParams.MultiSelection = true;
                oCFLCreationParams.ObjectType = objectid;
                oCFLCreationParams.UniqueID = cflID;
                oCFL = oCFLs.Add(oCFLCreationParams);
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        public void AddChooseFromList_WithCond(SAPbouiCOM.Form oFormChoose, string cflID, string objectid, string query, string Alias, ArrayList alCond)
        {
            SAPbouiCOM.ChooseFromList oCFL = null;
            SAPbouiCOM.Conditions oCons = null;
            SAPbouiCOM.Condition oCon = null;
            try
            {
                try
                {
                    SAPbouiCOM.ChooseFromListCollection oCFLs = null;
                    oCFLs = oForm.ChooseFromLists;
                    SAPbouiCOM.ChooseFromListCreationParams oCFLCreationParams = null;
                    oCFLCreationParams = ((SAPbouiCOM.ChooseFromListCreationParams)(oApplication.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_ChooseFromListCreationParams)));
                    oCFLCreationParams.MultiSelection = false;
                    oCFLCreationParams.ObjectType = objectid;
                    oCFLCreationParams.UniqueID = cflID;
                    oCFL = oCFLs.Add(oCFLCreationParams);
                }
                catch
                {
                    oCFL = oFormChoose.ChooseFromLists.Item(cflID);
                }
                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();



                #region Filter CFL values using ArrayList
                if (query == string.Empty)
                {
                    for (int i = 0; i < alCond.Count; i++)
                    {
                        if (oCons.Count > 0) //'If there are already user conditions.
                        {
                            oCons.Item(oCons.Count - 1).Relationship = (SAPbouiCOM.BoConditionRelationship)((alCond[i] as ArrayList)[0]);
                        }
                        oCon = oCons.Add();
                        oCon.BracketOpenNum = 1;
                        oCon.Alias = (alCond[i] as ArrayList)[1].ToString();
                        oCon.CondVal = (alCond[i] as ArrayList)[2].ToString();
                        oCon.Operation = (SAPbouiCOM.BoConditionOperation)((alCond[i] as ArrayList)[3]); //SAPbouiCOM.BoConditionOperation.co_EQUAL;                      
                        oCon.BracketCloseNum = 1;
                        oCFL.SetConditions(oCons);
                    }
                }
                #endregion

                #region Filter CFL values using recordset
                else
                {
                    oRs = returnRecord(query);
                    if (oRs.RecordCount == 0)
                    {
                        oCon = oCons.Add();
                        oCon.Alias = Alias;
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = "1";
                        oCFL.SetConditions(oCons);
                    }
                    else
                    {
                        while (!oRs.EoF)
                        {
                            if (oCons.Count > 0) //'If there are already user conditions.
                            {
                                oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                            }
                            oCon = oCons.Add();
                            oCon.Alias = Alias;
                            oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                            oCon.CondVal = oRs.Fields.Item(0).Value.ToString();
                            oRs.MoveNext();
                            oCFL.SetConditions(oCons);
                        }
                    }
                }
                #endregion


            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        #region AddRow And DeleteRow


        public void AddRow(SAPbouiCOM.Matrix oMatrix, SAPbouiCOM.DBDataSource oDbDataSource, string Value)
        {
            oMatrix.FlushToDataSource();
            if (oMatrix.VisualRowCount == 0)
                oMatrix.AddRow(1, oMatrix.RowCount);
            else
            {

                if (Value != string.Empty)
                {
                    oDbDataSource.InsertRecord(oMatrix.RowCount);
                    oMatrix.LoadFromDataSource();
                }
            }
        }


        #endregion

        #region Allocate Batch
        public void AllocateBatch_41(SAPbouiCOM.Form Base_Form, SAPbouiCOM.Form oForm, SAPbouiCOM.Matrix Base_Matrix, SAPbouiCOM.Matrix Batch_Matrix1, SAPbouiCOM.Matrix Batch_Matrix2)
        {
            SAPbouiCOM.EditText oEdit;
            try
            {
                string Base_ItemCode, Base_Batch, Batch_Managed, Batch_Matrix1_Item;
                int Batch_Row = 1;
                for (int i = 1; i < Base_Matrix.VisualRowCount; i++)
                {
                    oEdit = ((SAPbouiCOM.EditText)(Base_Matrix.GetCellSpecific("1", i)));
                    Base_ItemCode = oEdit.String;
                    oEdit = ((SAPbouiCOM.EditText)(Base_Matrix.GetCellSpecific("U_Batch", i)));
                    Base_Batch = oEdit.String;

                    Batch_Managed = SelectRecord("SELECT T2.[ManBtchNum] FROM  OITM T2  where  T2.Itemcode='" + Base_ItemCode + "'");
                    if (Batch_Managed == "Y")
                    {
                        for (; Batch_Row <= Batch_Matrix1.VisualRowCount;)
                        {
                            oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix1.GetCellSpecific("5", Batch_Row)));
                            Batch_Matrix1_Item = oEdit.String;
                            try
                            {
                                Batch_Matrix1.Columns.Item("5").Cells.Item(Batch_Row).Click(SAPbouiCOM.BoCellClickType.ct_Regular, 0);
                            }
                            catch { }
                            oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("2", 1)));
                            if (oEdit.String == "")
                            {
                                oEdit.String = Base_Batch;

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("7", 1))); //Batch Att 1
                                //try
                                //{
                                //    oEdit.String = Base_Att1;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("8", 1)));//Batch Att 2
                                //try
                                //{
                                //    oEdit.String = Base_Att2;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("10", 1)));//Exp Date
                                //try
                                //{
                                //    oEdit.String = Base_Exp_Date;
                                //}
                                //catch { }

                                oEdit = ((SAPbouiCOM.EditText)(Batch_Matrix2.GetCellSpecific("11", 1)));//Manf Date
                                //try
                                //{
                                //    oEdit.String = Base_Man_Date;
                                //}
                                //catch { }

                                oItem = oForm.Items.Item("1");
                                oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                if (Batch_Row == Batch_Matrix1.VisualRowCount)
                                {
                                    oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    oItem = Base_Form.Items.Item("1");
                                    oItem.Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                }
                                Batch_Row++;
                                break;
                            }
                            else
                            {
                                Batch_Row++;
                                break;
                            }
                        }
                    }
                }
            }
            catch
            {

            }
        }
        #endregion

        #region Select Records
        public string SelectRecord(string Querry)
        {
            SAPbobsCOM.Recordset oRS_Select = null;
            try
            {
                string str = "";
                oRS_Select = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRS_Select.DoQuery(Querry);

                if (oRS_Select.EoF == false)
                {
                    str = oRS_Select.Fields.Item(0).Value.ToString();
                }
                else
                {
                    str = "";
                }
                return str;
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, false);
                return ex.Message;
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRS_Select);
                oRS_Select = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

        }

        public SAPbobsCOM.Recordset returnRecord(string Query)
        {
            try
            {
                oRs = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                oRs.DoQuery(Query);
                return oRs;
            }
            catch
            {
                return oRs;
            }
        }
        #endregion

        #region FillCombo
        public void FillCombo(SAPbouiCOM.ComboBox oCombo, string Query)
        {
            try
            {

                try
                {
                    oCombo.ValidValues.Remove("", SAPbouiCOM.BoSearchKey.psk_ByValue);
                }
                catch
                {

                }
                int Count = oCombo.ValidValues.Count;
                for (int i = 0; i < Count; i++)
                {
                    try
                    {
                        oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                    }
                    catch { }
                }
                SAPbobsCOM.Recordset InsertRec = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                InsertRec.DoQuery(Query);

                //if (iType != 5)
                //{
                oCombo.ValidValues.Add("", "");
                // }
                if (!InsertRec.EoF)
                {
                    for (int i = 0; i < InsertRec.RecordCount; i++)
                    {
                        if (InsertRec.Fields.Item(1).Value.ToString().Length <= 5)
                        {
                            // ADD SPACE TO AVOID VALIDATION ERROR 
                            oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    " + InsertRec.Fields.Item(1).Value.ToString());
                            // oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");

                        }
                        else if (InsertRec.Fields.Item(1).Value.ToString().Length > 50)
                        {
                            // REMOVE EXCESS CHARACTER TO AVOID VALIDATION ERROR
                            oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), InsertRec.Fields.Item(1).Value.ToString().Substring(0, 49));
                            //oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");
                        }
                        else
                        {
                            //oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), "    ");
                            oCombo.ValidValues.Add(InsertRec.Fields.Item(0).Value.ToString(), InsertRec.Fields.Item(1).Value.ToString());

                        }
                        InsertRec.MoveNext();

                    }
                }


            }
            catch { }
        }
        #endregion

        #region Bind_Radio  & Checkbox

        public void Bind_Radio(SAPbouiCOM.Form oForm, int NoOfRButton)
        {
            SAPbouiCOM.OptionBtn opt;
            SAPbouiCOM.UserDataSource oUserdatasource;


            try
            {
                if (NoOfRButton == 2)
                {
                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");


                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 3)
                {
                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 4)
                {
                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 5)
                {
                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");
                    opt.Selected = true;
                }



                else if (NoOfRButton == 6)
                {
                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt6");

                    //oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    //opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");
                    opt.Selected = true;
                }

                else if (NoOfRButton == 7)
                {
                    oItem = oForm.Items.Item("opt7");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt7");

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt6");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt3");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");

                    opt.Selected = true;
                }

                else if (NoOfRButton == 23)
                {
                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 22)
                {
                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
                else if (NoOfRButton == 232)
                {
                    oItem = oForm.Items.Item("opt7");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD3", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD3");

                    oItem = oForm.Items.Item("opt6");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt7");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt5");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);

                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD2", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD2");

                    oItem = oForm.Items.Item("opt4");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt5");

                    oItem = oForm.Items.Item("opt3");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt4");
                    opt.Selected = true;

                    oItem = oForm.Items.Item("opt2");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    oUserdatasource = oForm.DataSources.UserDataSources.Add("BD1", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 5);
                    opt.DataBind.SetBound(true, "", "BD1");

                    oItem = oForm.Items.Item("opt1");
                    opt = (SAPbouiCOM.OptionBtn)(oItem.Specific);
                    opt.GroupWith("opt2");
                    opt.Selected = true;
                }
            }
            catch
            { }

        }

        public void Bind_CheckBox(SAPbouiCOM.Form oForm, string ItemUID)
        {
            SAPbouiCOM.UserDataSource oUserdatasource;
            try
            {
                oItem = oForm.Items.Item(ItemUID);
                SAPbouiCOM.CheckBox chk = (SAPbouiCOM.CheckBox)(oItem.Specific);

                oUserdatasource = oForm.DataSources.UserDataSources.Add("CHK", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 1);
                chk.DataBind.SetBound(true, "", "CHK");



            }
            catch
            { }

        }

        #endregion

        #region Return Proper Date Format

        public string GetDateFormat(string sDate)
        {
            try
            {
                string sDateFormat = sDate.Substring(0, 4) + "/" + sDate.Substring(4, 2) + "/" + sDate.Substring(6, 2);
                return sDateFormat;
            }
            catch { return ""; }
        }

        #endregion

        #region Condition on ChooseFromList
        public void AddCondOnCFLCodeWise(SAPbouiCOM.Form frmRFQ, string objectid, string query, string Alias)
        {
            try
            {
                oCFL = frmRFQ.ChooseFromLists.Item(objectid);
                oRs = returnRecord(query);

                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();
                if (query == "")
                {

                }
                else if (oRs.RecordCount == 0)
                {
                    oCon = oCons.Add();
                    oCon.Alias = Alias;
                    oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                    oCon.CondVal = "1";
                    oCFL.SetConditions(oCons);
                }
                else
                {
                    while (!oRs.EoF)
                    {
                        if (oCons.Count > 0) //'If there are already user conditions.
                        {
                            oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                        }
                        oCon = oCons.Add();
                        oCon.Alias = Alias;
                        oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCon.CondVal = oRs.Fields.Item(0).Value.ToString();
                        oRs.MoveNext();
                        oCFL.SetConditions(oCons);
                    }
                }

            }
            catch
            {

            }
        }
        public void AddCondOnCFLCodeWise(SAPbouiCOM.Form frmRFQ, string objectid, string SeriesNo)
        {
            try
            {
                oCFL = frmRFQ.ChooseFromLists.Item(objectid);
                oCFL.SetConditions(null);
                oCons = oCFL.GetConditions();

                if (oCons.Count > 0) //'If there are already user conditions.
                {
                    oCons.Item(oCons.Count - 1).Relationship = SAPbouiCOM.BoConditionRelationship.cr_AND;
                }
                oCon = oCons.Add();
                oCon.BracketOpenNum = 1;
                oCon.Alias = "Series";
                oCon.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                oCon.CondVal = SeriesNo;
                oCon.BracketCloseNum = 1;
                oCFL.SetConditions(oCons);
            }
            catch
            {

            }
        }
        #endregion

        #region GetDefaultSeries

        public int GetDefaultSeries(string ObjectType)
        {
            SAPbobsCOM.CompanyService oCmpSrv = null;
            SAPbobsCOM.SeriesService oSeriesService = null;
            SAPbobsCOM.DocumentTypeParams oDocumentTypeParams = null;
            SAPbobsCOM.Series oSeries = null;

            //'get company service
            oCmpSrv = (SAPbobsCOM.CompanyService)oCompany.GetCompanyService();
            //'get series service
            oSeriesService = (SAPbobsCOM.SeriesService)oCmpSrv.GetBusinessService(SAPbobsCOM.ServiceTypes.SeriesService);
            //'get new series
            oSeries = (SAPbobsCOM.Series)oSeriesService.GetDataInterface(SAPbobsCOM.SeriesServiceDataInterfaces.ssdiSeries);
            //'get DocumentTypeParams for filling the document type
            oDocumentTypeParams = (SAPbobsCOM.DocumentTypeParams)oSeriesService.GetDataInterface(SAPbobsCOM.SeriesServiceDataInterfaces.ssdiDocumentTypeParams);
            //'set the document type (e.g. A/R Invoice=13)
            oDocumentTypeParams.Document = ObjectType;
            //'get the default series of the SaleOrder documentset the document type
            oSeries = oSeriesService.GetDefaultSeries(oDocumentTypeParams);
            int i = oSeries.Series;
            SerNo = oSeries.Series;
            SerName = oSeries.Name;
            return i;
        }

        #endregion

        #region GetMaxDocNum
        public int GetMaxDocNum(string objCode, int series)
        {
            string QueryString = "";
            int MaxCode = 0;
            SAPbobsCOM.Recordset InsertRec = null;
            QueryString = "SELECT MAX(NextNumber) FROM NNM1 WHERE ObjectCode='" + objCode + "' AND Series= " + series + "";
            InsertRec = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
            InsertRec.DoQuery(QueryString);

            if (InsertRec.EoF == false)
            {
                MaxCode = Convert.ToInt16(InsertRec.Fields.Item(0).Value);
            }

            return MaxCode;
        }
        #endregion

        #region GoodsIssue_Production

        public void GoodsIssue_PO_Datatable(System.Data.DataTable dt, out string GRDocEntry, string PODocEntry, string WODocEntry)
        {
            //Goods Issue object. 60        
            int lretcode;
            string ItemCode, WhsCode;
            double Quantity;

            SAPbobsCOM.Documents IssueToProd = null;
            IssueToProd = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenExit));

            IssueToProd.DocDate = DateTime.Now;
            string BaseDoc = SelectRecord("SELECT DOCNUM FROM OWOR WHERE DOCENTRY=" + PODocEntry + "");
            IssueToProd.JournalMemo = "Issue for Production " + BaseDoc;
            IssueToProd.Comments = "Issue for Production " + BaseDoc;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IssueToProd.Lines.SetCurrentLine(i);
                ItemCode = dt.Rows[i]["Itemcode"].ToString();
                WhsCode = dt.Rows[i]["WareHouse"].ToString();
                Quantity = double.Parse(dt.Rows[i]["Quantity"].ToString());

                IssueToProd.Lines.BaseType = 202;
                IssueToProd.Lines.BaseEntry = int.Parse(PODocEntry);
                IssueToProd.Lines.BaseLine = i;
                IssueToProd.Lines.Quantity = Quantity;
                IssueToProd.Lines.WarehouseCode = WhsCode;

                IssueToProd.Lines.BatchNumbers.SetCurrentLine(0);
                IssueToProd.Lines.BatchNumbers.BatchNumber = dt.Rows[i]["Batch"].ToString();
                IssueToProd.Lines.BatchNumbers.Quantity = Quantity;
                IssueToProd.Lines.BatchNumbers.Add();
                IssueToProd.Lines.Add();
            }

            lretcode = IssueToProd.Add();

            if (lretcode != 0)
            {
                int Errcode; string ErrMsg;
                oCompany.GetLastError(out Errcode, out ErrMsg);
                oApplication.MessageBox("Issue for Production : " + ErrMsg, 1, "OK", "", "");
                oApplication.StatusBar.SetText("Issue for Production : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = "";
            }
            else
            {
                oApplication.StatusBar.SetText("Issue for Production created successfully.....!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = oCompany.GetNewObjectKey();
            }

        }


        #region GoodsIssue_Production


        public void GoodsReceipt_Production(string FormUID, string Form_DocEntry, string sDocNum, string sDocDate, string sShift, string sRemks, out string GRDocEntry, SAPbouiCOM.Matrix oMtx1, SAPbouiCOM.Matrix oMtx2)
        {
            //Goods Issue object. 59       
            GRDocEntry = string.Empty;
            int lretcode;
            string ItemCode, WhsCode, RejWhsCode, DocEntry;
            double Quantity, RejQty;
            SAPbobsCOM.Recordset oRsGI = null;
            string type = "";
            string BaseEntry = string.Empty;
            if (FormUID == "TIS_BCP")
            {
                type = "BCPNo-";
                BaseEntry = "BCP-" + Form_DocEntry;
            }
            else if (FormUID == "TIS_PRCONFEX")
            {
                type = "PCONExtNo-";
                BaseEntry = "EXT-" + Form_DocEntry;
            }
            else if (FormUID == "TIS_PRCONAND")
            {
                type = "PCONANDNo-";
                BaseEntry = "AND-" + Form_DocEntry;
            }

            if (Form_DocEntry != string.Empty)
            {
                string IsAlreadyExist = SelectRecord("SELECT DOCENTRY FROM IGN1 WHERE U_BaseEntry='" + BaseEntry + "'");
                if (IsAlreadyExist != string.Empty)
                {
                    oApplication.SetStatusBarMessage("Goods Receipt is already created.", SAPbouiCOM.BoMessageTime.bmt_Short, false);
                    return;
                }
            }

            //else if (FormUID == "TIS_PRCONAND")
            //{
            //    type = "PCONANDNo-";
            //}

            SAPbobsCOM.Documents Prod = null;
            Prod = (SAPbobsCOM.Documents)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInventoryGenEntry));

            //[[Pri]]
            string dDate = sDocDate.Substring(0, 4) + "/" + sDocDate.Substring(4, 2) + "/" + sDocDate.Substring(6, 2);
            DateTime d1 = Convert.ToDateTime(dDate);
            string msg2 = sShift.ToString().Trim() + "," + type + sDocNum + ",PDt-" + dDate.ToString();

            Prod.DocDate = d1;
            Prod.JournalMemo = "G.Recpt," + msg2;
            Prod.Comments = sRemks;





            //Prod.DocDate = DateTime.Now;
            int Row = 0;
            for (int i = 1; i <= oMtx2.VisualRowCount; i++)
            {
                ItemCode = ((SAPbouiCOM.EditText)oMtx2.GetCellSpecific("V_5", i)).String;
                if (ItemCode == "")
                {
                    break;
                }
                WhsCode = ((SAPbouiCOM.EditText)oMtx2.GetCellSpecific("V_1", i)).String;
                Quantity = double.Parse(((SAPbouiCOM.EditText)oMtx2.GetCellSpecific("V_0", i)).String);
                DocEntry = ((SAPbouiCOM.EditText)oMtx1.GetCellSpecific("V_7", i)).String;


                if (Quantity > 0)
                {
                    if (Row > 0)
                    {
                        Prod.Lines.Add();
                    }
                    Prod.Lines.BaseType = 202;
                    Prod.Lines.BaseEntry = int.Parse(DocEntry);
                    Prod.Lines.Quantity = Quantity;
                    Prod.Lines.WarehouseCode = WhsCode;
                    Prod.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntComplete;
                    Prod.Lines.UserFields.Fields.Item("U_BaseEntry").Value = BaseEntry;
                    Prod.Lines.SetCurrentLine(Row);
                    Row++;
                }


                RejQty = double.Parse(((SAPbouiCOM.EditText)oMtx2.GetCellSpecific("V_2", i)).String);
                RejWhsCode = ((SAPbouiCOM.EditText)oMtx2.GetCellSpecific("V_3", i)).String;
                if (RejQty > 0)
                {
                    if (Row > 0)
                    {
                        Prod.Lines.Add();
                    }
                    Prod.Lines.BaseType = 202;
                    Prod.Lines.BaseEntry = int.Parse(DocEntry);
                    Prod.Lines.Quantity = RejQty;
                    Prod.Lines.WarehouseCode = RejWhsCode;
                    Prod.Lines.TransactionType = SAPbobsCOM.BoTransactionTypeEnum.botrntReject;
                    Prod.Lines.UserFields.Fields.Item("U_BaseEntry").Value = BaseEntry;

                    Prod.Lines.SetCurrentLine(Row);
                    Row++;
                }
            }
            /*Prod.JournalMemo = "Receipt from Production " + BaseDoc;
            Prod.Comments = "Receipt from Production " + BaseDoc;

            oRsGI = returnReocord("SELECT ItemCode,WareHouse,DocEntry,PlannedQty [Quantity] FROM OWOR WHERE DocEntry=" + BaseDoc + " ");
            int Row = 0;
            while (!oRsGI.EoF)
            {
                ItemCode = oRsGI.Fields.Item("ItemCode").Value.ToString();
                WhsCode = oRsGI.Fields.Item("WareHouse").Value.ToString();
                Quantity = double.Parse(oRsGI.Fields.Item("Quantity").Value.ToString());


                Prod.Lines.BaseType = 202;
                Prod.Lines.BaseEntry = int.Parse(oRsGI.Fields.Item("DocEntry").Value.ToString());
                //Prod.Lines.BaseLine = int.Parse(oRsGI.Fields.Item("LineNum").Value.ToString());
                // IssueToProd.Lines.ItemCode = ItemCode;
                Prod.Lines.Quantity = Quantity;
                Prod.Lines.WarehouseCode = WhsCode;

                string BatchNo = SelectReocord("SELECT U_BATCh FROM [@TIS_WO] WHERE DOCENTRY=" + WODocEntry + "");
                Prod.Lines.BatchNumbers.BatchNumber = BatchNo;
                Prod.Lines.BatchNumbers.Quantity = Quantity;


                if (Row > 0)
                {
                    Prod.Lines.Add();
                }
                Prod.Lines.SetCurrentLine(Row);
                Row++;
                oRsGI.MoveNext();
            }*/

            lretcode = Prod.Add();

            if (lretcode != 0)
            {
                int Errcode; string ErrMsg;//05007BR3165
                oCompany.GetLastError(out Errcode, out ErrMsg);
                oApplication.MessageBox("Receipt From Production  : " + ErrMsg, 1, "OK", "", "");
                oApplication.StatusBar.SetText("Receipt From Production  : " + ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = "";
            }
            else
            {
                //oApplication.StatusBar.SetText("Receipt from Production created successfully.....!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                GRDocEntry = oCompany.GetNewObjectKey();
            }

        }

        #endregion 

        #endregion

        #region GetPeriod
        public void GetPeriod()
        {
            try
            {
                SAPbouiCOM.Company company = oApplication.Company;
                int Period = company.CurrentPeriod;
                SAPbobsCOM.CompanyService oCompanyService = oCompany.GetCompanyService();
                SAPbobsCOM.FinancePeriodParams diPeriodParams = (SAPbobsCOM.FinancePeriodParams)oCompanyService.GetDataInterface(SAPbobsCOM.CompanyServiceDataInterfaces.csdiFinancePeriodParams);

                diPeriodParams.AbsoluteEntry = Period;
                SAPbobsCOM.FinancePeriod finPeriod = oCompanyService.GetFinancePeriod(diPeriodParams);

            }
            catch { }
        }
        #endregion

        #region Remove_UDF
        public void Remove_UDF(string sTableID, string sFieldName)
        {
            oUserFieldsMD = (SAPbobsCOM.UserFieldsMD)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);

            try
            {
                int iFieldID = GetFieldID(sTableID, sFieldName);
                if (oUserFieldsMD.GetByKey(sTableID, iFieldID))
                {
                    if (oUserFieldsMD.Remove() != 0) oApplication.SetStatusBarMessage("Error removing UDF: " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, true);
                }
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldsMD);
                oUserFieldsMD = null;
                GC.Collect();
            }
        }

        private int GetFieldID(string sTableID, string sAliasID)
        {
            int iRetVal = 0;
            SAPbobsCOM.Recordset sboRec = (SAPbobsCOM.Recordset)oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
            try
            {
                sboRec.DoQuery("select FieldID from CUFD where TableID = '" + sTableID + "' and AliasID = '" + sAliasID + "'");
                if (!sboRec.EoF) iRetVal = Convert.ToInt32(sboRec.Fields.Item("FieldID").Value.ToString());
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(sboRec);
                sboRec = null;
                GC.Collect();
            }
            return iRetVal;
        }
        #endregion

        public void SetAutoManagedAttribute_AddMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, -1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute_UpdateMode(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
        }

        public void SetAutoManagedAttribute(SAPbouiCOM.Item oItem)
        {
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 1, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 2, SAPbouiCOM.BoModeVisualBehavior.mvb_False);
            oItem.SetAutoManagedAttribute(SAPbouiCOM.BoAutoManagedAttr.ama_Editable, 3, SAPbouiCOM.BoModeVisualBehavior.mvb_False);

        }

        public DateTime ConvertStrToDate(string strDate, string strFormat)
        {
            DateTime oDate = default(DateTime);
            try
            {

                System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo("en-GB", false);
                System.Globalization.CultureInfo newCi = (System.Globalization.CultureInfo)ci.Clone();

                System.Threading.Thread.CurrentThread.CurrentCulture = newCi;
                oDate = DateTime.ParseExact(strDate, strFormat, ci.DateTimeFormat);


            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, true);
            }
            finally
            {

            }
            return oDate;

        }

        public SqlConnection DBConnection()
        {
            SqlConnection conn = null;

            SAPbobsCOM.Recordset InsertRec = null;
            string QueryString = null;
            //--
            try
            {
                //SetConnection
                QueryString = "SELECT U_DBPwd FROM [@TIS_DATABASE]";
                InsertRec = ((SAPbobsCOM.Recordset)(oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)));
                InsertRec.DoQuery(QueryString);

                if (!InsertRec.EoF)
                {
                    clsVariables.DbPass = InsertRec.Fields.Item("U_DBPwd").Value.ToString();
                }
                else
                    oApplication.MessageBox("Database Connection details missing in user defined table!", 1, "OK", "", "");
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return null;
            }
            try
            {
                clsVariables.Server = oCompany.Server;
                clsVariables.DbName = oCompany.CompanyDB;
                clsVariables.DbUser = oCompany.DbUserName;


                string strConn = "SERVER='" + oCompany.Server + "';DATABASE='" + oCompany.CompanyDB + "';USER ID='" + oCompany.DbUserName + "';Password='" + clsVariables.DbPass + "'";
                conn = new SqlConnection(strConn);
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return null;
            }
            return conn;
        }

        public void Form_Duplicate(SAPbouiCOM.Form oForm, string Code)
        {
            UserObjectsMD udo = (UserObjectsMD)oCompany.GetBusinessObject(BoObjectTypes.oUserObjectsMD);
            string value = string.Empty;
            if (udo.GetByKey(oForm.BusinessObject.Type) == true)
            {
                string[] str_tables = new string[udo.ChildTables.Count + 1];
                str_tables[0] = "@" + udo.TableName;

                for (int iPos = 0, tableCount = udo.ChildTables.Count; iPos < tableCount; iPos++)
                {
                    udo.ChildTables.SetCurrentLine(iPos);
                    value = "@" + udo.ChildTables.TableName;
                    str_tables[iPos + 1] = "@" + udo.ChildTables.TableName;
                }

                System.Runtime.InteropServices.Marshal.FinalReleaseComObject(udo);
                udo = null;

                SAPbouiCOM.DBDataSources dbSources = oForm.DataSources.DBDataSources;
                foreach (SAPbouiCOM.DBDataSource datasource in dbSources)
                {
                    for (int i = 0; i < str_tables.Length; i++)
                    {
                        if (str_tables[i].Contains(datasource.TableName))
                        {
                            for (int iPos = 0, recordCount = datasource.Size; iPos < recordCount; iPos++)
                            {
                                datasource.SetValue("Code", iPos, Code);
                            }
                            break;
                        }
                    }
                }

                foreach (SAPbouiCOM.Item oItem in oForm.Items)
                {
                    if (SAPbouiCOM.BoFormItemTypes.it_MATRIX == oItem.Type)
                    {
                        oMatrix = (SAPbouiCOM.Matrix)oItem.Specific;
                        oMatrix.LoadFromDataSourceEx(true);
                    }
                }
            }
        }

        public void ModifyForm(SAPbouiCOM.Form oForm)
        {

            try
            {
                SAPbouiCOM.Item xItem;
                SAPbouiCOM.Button oButton;

                #region Pick List
                if (oForm.TypeEx == "85")
                {
                    xItem = oForm.Items.Item("4");
                    oItem = oForm.Items.Add("btnFill", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                    oItem.Left = xItem.Left + xItem.Width + 2;
                    oItem.Top = xItem.Top;

                    oItem.Width = oItem.Width + oItem.Width;
                    oItem.Height = xItem.Height;

                    oButton = (SAPbouiCOM.Button)(oItem.Specific);
                    oButton.Caption = "Fill Rate";
                    //oItem.Width = 60;

                }
                #endregion


            }
            catch (Exception e)
            {
                oApplication.StatusBar.SetText(e.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FillCombo_Series_Custom(SAPbouiCOM.Form oForm, string ObjectCode, string SeriesCombo, string SeriesUDF, string Mode)
        {
            try
            {
                SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(SeriesCombo).Specific;
                //string ObjectCode = oForm.DataSources.DBDataSources.Item(0).TableName.Replace("@", string.Empty);

                if (Mode == "Load")
                {
                    string DOCDATE = ((SAPbouiCOM.EditText)oForm.Items.Item(SeriesUDF).Specific).Value;
                    StringBuilder sbQuery = new StringBuilder();

                    sbQuery.Append(" SELECT T0.SERIES, T0.SERIESNAME  FROM NNM1 T0  ");
                    sbQuery.Append(" INNER JOIN OFPR T1 ON T0.INDICATOR = T1.INDICATOR  ");
                    sbQuery.Append(" WHERE OBJECTCODE='" + ObjectCode + "'  AND     LOCKED = 'N'  ");
                    sbQuery.Append(" AND F_REFDATE <='" + DOCDATE + "'  AND T_REFDATE >= '" + DOCDATE + "'  ");
                    sbQuery.Append(" GROUP BY T0.SERIES, T0.SERIESNAME  ");


                    int Count = oCombo.ValidValues.Count;
                    for (int i = 0; i < Count; i++)
                    {
                        try
                        {
                            oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                        }
                        catch { }
                    }
                    oRs = returnRecord(sbQuery.ToString());
                    while (!oRs.EoF)
                    {
                        try
                        {
                            oCombo.ValidValues.Add(oRs.Fields.Item("SERIES").Value.ToString(), oRs.Fields.Item("SERIESNAME").Value.ToString());
                        }
                        catch { }
                        oRs.MoveNext();
                    }

                    oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index);

                }
                else
                {
                    oCombo.ValidValues.LoadSeries(ObjectCode, SAPbouiCOM.BoSeriesMode.sf_View);

                }
            }
            catch
            {
                oApplication.StatusBar.SetText("Error while loading series", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        public void FillCombo_UDFValue(SAPbouiCOM.ComboBox oCombo, string TableName, string FieldName)
        {
            SAPbobsCOM.SBObob obj = (SAPbobsCOM.SBObob)oCompany.GetBusinessObject(BoObjectTypes.BoBridge);
            SAPbobsCOM.Recordset InsertRec = obj.GetFieldValidValues(TableName, FieldName);
            int Count = oCombo.ValidValues.Count;
            for (int i = 0; i < Count; i++)
            {
                try
                {
                    oCombo.ValidValues.Remove(oCombo.ValidValues.Count - 1, SAPbouiCOM.BoSearchKey.psk_Index);
                }
                catch { }
            }
        }

        public void ReportService()
        {
            SAPbobsCOM.ReportTypesService rptTypeService = (SAPbobsCOM.ReportTypesService)oCompany.GetCompanyService().GetBusinessService(SAPbobsCOM.ServiceTypes.ReportTypesService);
            SAPbobsCOM.ReportType newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Delivery Order";  //Name of SubMenu
            newType.MenuID = "DEL_ORDER";
            string AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }

            newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Dispatch Planning";  //Name of SubMenu
            newType.MenuID = "DISP_PLAN";
            AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }


            newType = (SAPbobsCOM.ReportType)rptTypeService.GetDataInterface(SAPbobsCOM.ReportTypesServiceDataInterfaces.rtsReportType);
            newType.AddonName = "Sales"; //New Menu Name in Add-on Layouts
            newType.TypeName = "Stuffing";  //Name of SubMenu
            newType.MenuID = "STUFF";
            AlreadyExist = SelectRecord("SELECT * FROM RTYP WHERE ADD_NAME='" + newType.AddonName + "' AND MNU_ID='" + newType.MenuID + "'");
            if (AlreadyExist == string.Empty)
            {
                SAPbobsCOM.ReportTypeParams newTypeParam = rptTypeService.AddReportType(newType);
            }
        }

        public void FillGrid(string formUID, string gridUID, string dataTableUID, string query, int collapseLevel)
        {
            oForm = oApplication.Forms.Item(formUID);
            try
            {
                oForm.DataSources.DataTables.Add(dataTableUID);
            }
            catch
            {
            }
            ((SAPbouiCOM.Grid)(oForm.Items.Item(gridUID).Specific)).DataTable = oForm.DataSources.DataTables.Item(dataTableUID);
            oForm.DataSources.DataTables.Item(dataTableUID).ExecuteQuery(query);
            ((SAPbouiCOM.Grid)(oForm.Items.Item(gridUID).Specific)).CollapseLevel = collapseLevel;
            ((SAPbouiCOM.Grid)(oForm.Items.Item(gridUID).Specific)).AutoResizeColumns();
            //((SAPbouiCOM.Grid)(oForm.Items.Item(gridUID).Specific)).SelectionMode = SAPbouiCOM.BoMatrixSelect.ms_Single;
        }

        #endregion
    }
}

