using System;
using System.Collections.Generic;
using System.Text;

namespace Torsa_Production
{
    class Connection
    {
        #region SAP Objects
        public static SAPbouiCOM.SboGuiApi oSboGuiApi;
        public static SAPbouiCOM.Application oApplication;
        public static SAPbobsCOM.Company oCompany;

        public SAPbouiCOM.CheckBox chk;

        public static SAPbouiCOM.EditText oEdit;
        public static SAPbobsCOM.Recordset oRs;
        public static string SuperUser;
        public static string Assemlbly;

        #endregion

        #region Methods

        /// <summary>
        /// Connect to SAP application
        /// </summary>
        public void ConnectToSAPApplication()
        {
            try
            {
                Main.logger.DebugFormat("> {0}", nameof(ConnectToSAPApplication));
                string devConnectionString = string.Empty;
                try
                {
                    devConnectionString = Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));
                }
                catch
                {
                    devConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
                }
                var sboGuiApi = new SAPbouiCOM.SboGuiApi();
                sboGuiApi.Connect(devConnectionString);

                oApplication = sboGuiApi.GetApplication();
                oCompany = (SAPbobsCOM.Company)oApplication.Company.GetDICompany();

                Assemlbly = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
                oApplication.StatusBar.SetText(Assemlbly + " addon connected successfully.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Connect Application Error: " + ex.Message);
            }
        }

        public void SetUIConnection()
        {
            string ConnectionString;
            try
            {
                ConnectionString = Convert.ToString(Environment.GetCommandLineArgs().GetValue(1));
            }
            catch
            {
                ConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
            }
            //ConnectionString = "0030002C0030002C00530041005000420044005F00440061007400650076002C0050004C006F006D0056004900490056";
            oSboGuiApi = new SAPbouiCOM.SboGuiApi();
            try
            {

                oSboGuiApi.Connect(ConnectionString);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("UI Connection Error: " + ex.Message);
                System.Environment.Exit(0);
            }
            oApplication = oSboGuiApi.GetApplication(-1);
            //System.Windows.Forms.MessageBox.Show("Addon Connected !");

            oApplication.StatusBar.SetText("Please wait.... " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon Connecting !", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
        }
        public bool SetDIConnection()
        {
            string sCookie;
            string sConnectionContext;

            oCompany = new SAPbobsCOM.Company();
            if (oCompany.Connected == true)
                return true;
            sCookie = oCompany.GetContextCookie();
            sConnectionContext = oApplication.Company.GetConnectionContext(sCookie);
            oCompany.SetSboLoginContext(sConnectionContext);
            int i = oCompany.Connect();
            if (i == 0)
            {
                oApplication.StatusBar.SetText(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon Connected !", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                return true;
            }
            else
            {
                oApplication.StatusBar.SetText(oCompany.GetLastErrorCode() + " : " + oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;

            }
        }

        #endregion
    }
}
