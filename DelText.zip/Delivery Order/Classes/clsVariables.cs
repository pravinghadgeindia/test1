using System;
using System.Collections.Generic;
using System.Text;

namespace General
{
    class clsVariables
    {

        #region Global Variable
        private static string sServer;
        private static string sDbName;
        private static string sDbUser;
        private static string sDbPass;
        private static string sDocEntry;
        private static string sBaseFormUID;
        private static bool oboolCFLSelected;
        private static int iRowNo, iColNo;
        private static SAPbouiCOM.Form oBaseForm;
        private static SAPbouiCOM.DataTable ostuffDataTable;

        #endregion

        # region Login Information

        public static string Server
        {
            get { return sServer; }
            set { sServer = value; }
        }

        public static string DbName
        {
            get { return sDbName; }
            set { sDbName = value; }
        }

        public static string DbUser
        {
            get { return sDbUser; }
            set { sDbUser = value; }
        }

        public static string DbPass
        {
            get { return sDbPass; }
            set { sDbPass = value; }
        }

        #endregion

        #region Variables

        public static string BaseFormUID
        {
            get { return sBaseFormUID; }
            set { sBaseFormUID = value; }
        }

        public static string DocEntry
        {
            get { return sDocEntry; }
            set { sDocEntry = value; }
        }

        public static bool boolCFLSelected
        {
            get { return oboolCFLSelected; }
            set { oboolCFLSelected = value; }
        }

        public static SAPbouiCOM.DataTable stuffDataTable
        {
            get { return ostuffDataTable; }
            set { ostuffDataTable = value; }
        }

        public static int RowNo
        {
            get { return iRowNo; }
            set { iRowNo = value; }
        }
        public static int ColNo
        {
            get { return iColNo; }
            set { iColNo = value; }
        }

        public static SAPbouiCOM.Form BaseForm
        {
            get { return oBaseForm; }
            set { oBaseForm = value; }
        }
        #endregion

    }
}
