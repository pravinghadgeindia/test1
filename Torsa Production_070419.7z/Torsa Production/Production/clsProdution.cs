using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;
using System.Globalization;

namespace Torsa_Production
{
    class clsProdution : Connection
    {
        #region Variables
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.ComboBox oCombo;

        string headerTable = "OWOR";
        string childTable = "WOR1";
        string formTitle = "Purchase Order";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                string query;
                                string OriginAbs = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("OriginAbs", 0).Trim();
                                string Project = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Project", 0).Trim();
                                string ItemCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("ItemCode", 0).Trim();
                                string PlannedQty = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("PlannedQty", 0).Trim();
                                string DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                query = "SELECT ONHAND-IsCommited FROM OITW WHERE ITEMCODE='" + ItemCode + "' AND WHSCODE='FG01'";
                                string onHand = objclsComman.SelectRecord(query);
                                double dblOnHand = onHand == string.Empty ? 0 : double.Parse(onHand);
                                if (dblOnHand > 0)
                                {
                                    int i = oApplication.MessageBox("Item has instock quantity more than 0. Do you want to proceed?", 1, "Yes", "No", "");
                                    if (i != 1)
                                    {
                                        BubbleEvent = false;
                                        return;
                                    }
                                }

                                #region Validation with SO Qty

                                query = "SELECT 1 FROM RDR1 WHERE DOCENTRY='" + OriginAbs + "' AND ITEMCODE='" + ItemCode + "'";
                                string isExist = objclsComman.SelectRecord(query);
                                if (isExist == "1")
                                {
                                    query = "SELECT QUANTITY FROM RDR1 WHERE DOCENTRY='" + OriginAbs + "' AND ITEMCODE='" + ItemCode + "'";
                                }
                                else
                                {
                                    query = "SELECT T0.Code FROM OITT T0 INNER JOIN ITT1 T1 ON T0.Code = T1.Father WHERE T1.Code ='" + ItemCode + "'";
                                    string parentItem = objclsComman.SelectRecord(query);

                                    query = "SELECT QUANTITY FROM RDR1 WHERE DOCENTRY='" + OriginAbs + "' AND ITEMCODE='" + parentItem + "'";
                                }
                                string qty = objclsComman.SelectRecord(query);
                                double orderQty = qty == string.Empty ? 0 : double.Parse(qty);
                                if (orderQty > 0)
                                {
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        query = "SELECT SUM(PLANNEDQTY) FROM OWOR WHERE OriginAbs='" + OriginAbs + "' AND ITEMCODE='" + ItemCode + "'";
                                    }
                                    else
                                    {
                                        query = "SELECT SUM(PLANNEDQTY) FROM OWOR WHERE OriginAbs='" + OriginAbs + "' AND ITEMCODE='" + ItemCode + "' AND DocEntry!='" + DocEntry + "'";
                                    }
                                    qty = objclsComman.SelectRecord(query);
                                    double Previous_POrderQty = qty == string.Empty ? 0 : double.Parse(qty);
                                    if (orderQty < Previous_POrderQty + double.Parse(PlannedQty))
                                    {
                                        oApplication.StatusBar.SetText("Production order quantity is more than sales order quantity of itemcode :" + ItemCode, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                        BubbleEvent = false;
                                        return;
                                    }
                                }

                                #endregion
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }


        #endregion
    }
}
