using System;
using System.Collections.Generic;
using System.Text;
using SAPbouiCOM;
using System.Data;
using System.Collections;

namespace General
{
    class clsDelOrder : Connection
    {
        #region Variables

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Item oItem;
        public SAPbouiCOM.DBDataSource oDbDataSource = null;
        clsCommon objclsComman = new clsCommon();

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.Matrix oMatrix;
        bool MultiInvoiceSelected = false;
        string formMenuUID = "DELORDER";
        string formTitle = "Delivery Order Status";

        string matrixUID = "mtx";
        string matrixPrimaryUDF = "U_CardCode";
        string buttonFilterUID = "btnFilter";
        string headerTable = "@DELORDER";
        string childTable = "@DELORDER1";
        string objType = "DELORDER";
        string CFL_CARDF = nameof(CFL_CARDF);
        string CFL_CARDT = nameof(CFL_CARDT);
        string poQtyColUID = "V_1";
        string delQtyColUID = "V_13";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true
                if (pVal.Before_Action == true)
                {
                    try
                    {
                        #region T_et_ITEM_PRESSED
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            #region pVal.ItemUID == "1"
                            if (pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE || oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                {
                                    if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocNum", 0).ToString().Trim() == string.Empty)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Document No can't be blank. Please select series.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    if (oMatrix.VisualRowCount == 0)
                                    {
                                        BubbleEvent = false;
                                        oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                        return;
                                    }
                                    else if (oMatrix.VisualRowCount == 1)
                                    {
                                        string ItemCode = ((SAPbouiCOM.EditText)oMatrix.GetCellSpecific("V_4", 1)).String;
                                        if (ItemCode == string.Empty)
                                        {
                                            BubbleEvent = false;
                                            oApplication.StatusBar.SetText("Please add rows in detail.", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                            return;
                                        }
                                    }
                                }
                            }
                            if ((pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Add) && pVal.FormMode == 1)
                                || pVal.ItemUID == Convert.ToString((int)SAPButtonEnum.Cancel))
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                oForm.DataSources.UserDataSources.Item("Close").Value = YesNoEnum.Y.ToString();
                            }

                            #endregion

                            else if (pVal.ItemUID == buttonFilterUID)
                            {
                                FillMatrix(pVal.FormUID);
                            }
                        }
                        #endregion

                        #region T_et_FORM_CLOSE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
                        {
                            oForm = oApplication.Forms.GetForm(pVal.FormTypeEx, pVal.FormTypeCount);
                            if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                            {

                            }
                            else if (oForm.DataSources.UserDataSources.Item("Close").Value == "N")//Close
                            {
                                BubbleEvent = false;
                            }
                        }
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

                #region Before_Action == false
                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        #region F_et_CHOOSE_FROM_LIST

                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
                        {
                            SAPbouiCOM.DataTable oDataTable = null;
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            SAPbouiCOM.IChooseFromListEvent oCFLEvento = (SAPbouiCOM.IChooseFromListEvent)pVal;
                            oDataTable = oCFLEvento.SelectedObjects;
                            string sCFL_ID = oCFLEvento.ChooseFromListUID;
                            string Value = string.Empty;

                            if (oDataTable == null || oForm.Mode == SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                            {
                                return;
                            }
                            if (oCFLEvento.ChooseFromListUID == CFL_CARDF)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_FrBPCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oForm.DataSources.UserDataSources.Item("U_FrBPName").ValueEx = oDataTable.GetValue(CommonFields.CardName, 0).ToString();
                            }
                            if (oCFLEvento.ChooseFromListUID == CFL_CARDT)
                            {
                                oDbDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                oDbDataSource.SetValue("U_ToBPCode", 0, oDataTable.GetValue(CommonFields.CardCode, 0).ToString());
                                oForm.DataSources.UserDataSources.Item("U_ToBPName").ValueEx = oDataTable.GetValue(CommonFields.CardName, 0).ToString();
                            }
                        }

                        #endregion

                        #region F_et_FORM_ACTIVATE
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
                        {
                            if (pVal.FormTypeEx == formMenuUID)
                            {
                                if (clsVariables.boolCFLSelected)
                                {
                                    clsVariables.boolCFLSelected = false;
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    oMatrix.SetCellFocus(clsVariables.RowNo, clsVariables.ColNo);
                                    clsVariables.RowNo = 0;
                                    clsVariables.ColNo = 0;
                                }
                                if (MultiInvoiceSelected == true)
                                {
                                    oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);

                                    //MultiInvoiceSelected = false;
                                    //oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item("mtx").Specific;
                                    //oMatrix.FlushToDataSource();

                                    //for (int i = 0; i < oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size; i++)
                                    //{
                                    //    string InvDocEntry = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvDocE", i).ToString().Trim();
                                    //    string InvDocNum = oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").GetValue("U_InvNo", i).ToString().Trim();


                                    //    objclsComman.returnRecord("SELECT * FROM OINV WHERE DOCENTRY='" + InvDocEntry + "'");
                                    //    string NewInvDocNum = oRs.Fields.Item("DocNum").Value.ToString();
                                    //    if (InvDocNum != NewInvDocNum)
                                    //    {
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvNo", i, oRs.Fields.Item("DocNum").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_CustRef", i, oRs.Fields.Item("NumAtCard").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_Curr", i, oRs.Fields.Item("DocCur").Value.ToString());
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_InvAmt", i, oRs.Fields.Item("DocTotal").Value.ToString());

                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_PayTerm", i, oRs.Fields.Item("U_PayTerm").Value.ToString());
                                    //        DateTime dt = DateTime.Parse(oRs.Fields.Item("DocDueDate").Value.ToString());
                                    //        string Date = dt.ToString("yyyyMMdd");
                                    //        oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").SetValue("U_DueDate", i, Date);
                                    //    }
                                    //}
                                    //int iFormRowsCount=oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").Size;
                                    //if (iFormRowsCount == oMatrix.RowCount)
                                    //{
                                    //    oForm.DataSources.DBDataSources.Item("@LODG_BILLS1").InsertRecord(oMatrix.VisualRowCount);
                                    //}
                                    //oMatrix.LoadFromDataSource();

                                    //Calc_TotalAmount(oForm);


                                }
                            }
                        }
                        #endregion

                        #region F_et_ITEM_PRESSED
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
                        {
                            if (pVal.FormTypeEx == "LODG_BILLS" && pVal.ItemUID == "1" && pVal.FormMode == 3)
                            {
                                oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                                string Code = oForm.DataSources.DBDataSources.Item("@LODG_BILLS").GetValue("DocNum", 0).ToString();
                                if (Code.Trim() == string.Empty)
                                {
                                    LoadForm("1282");
                                    //AutoCode(oForm);

                                    return;
                                }

                            }
                        }
                        #endregion

                        #region F_et_COMBO_SELECT
                        else if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
                        {
                            try
                            {
                                if (pVal.ItemUID == "Series")
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(headerTable);
                                        oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item(pVal.ItemUID).Specific;
                                        if (oCombo.Value == null)
                                        {

                                        }
                                        else
                                        {
                                            int idefaultseries = Int32.Parse(oCombo.Selected.Value.Trim());
                                            string MaxCode = oForm.BusinessObject.GetNextSerialNumber(idefaultseries.ToString(), objType).ToString();//objclsComman.GetMaxDocNum("KIT_PO", idefaultseries);
                                            oDBDataSource.SetValue("DocNum", 0, Convert.ToString(MaxCode));
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                oApplication.StatusBar.SetText(" Item Event F_et_COMBO_SELECT : " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                            }
                        }
                        #endregion

                        #region F_pVal.ItemChanged == true
                        if (pVal.ItemChanged == true)
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);

                            if (pVal.ItemUID == "DocDate")
                            {
                                objclsComman.FillCombo_Series_Custom(oForm, pVal.ItemUID, "Load");
                                oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                                if (oCombo.ValidValues.Count == 0)
                                {
                                    oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, string.Empty);
                                }
                            }
                            else if (pVal.ItemUID == "FrBPCode")
                            {
                                if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrBPCode", 0).Trim() == string.Empty)
                                {
                                    oForm.DataSources.UserDataSources.Item("U_FrBPName").Value = string.Empty;
                                }
                            }
                            else if (pVal.ItemUID == "ToBPCode")
                            {
                                if (oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToBPCode", 0).Trim() == string.Empty)
                                {
                                    oForm.DataSources.UserDataSources.Item("U_ToBPName").Value = string.Empty;
                                }
                            }
                            else if (pVal.ItemUID == matrixUID)
                            {
                                if (pVal.ColUID == poQtyColUID || pVal.ColUID == delQtyColUID)
                                {
                                    oForm = oApplication.Forms.Item(pVal.FormUID);
                                    oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                                    oMatrix.FlushToDataSource();
                                    oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
                                    calcBal(oDbDataSource, pVal.Row-1);
                                    oMatrix.LoadFromDataSource();
                                }
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText(formTitle + " Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }
                #endregion

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(formTitle + " Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (pVal.BeforeAction == true)
                {
                    oForm = oApplication.Forms.ActiveForm;

                    if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                        {
                            //Record is directly added without validation
                            BubbleEvent = false;
                        }
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.UDFForm))
                    {
                        BubbleEvent = false;
                        return;
                    }
                }
                if (pVal.BeforeAction == false)
                {
                    if (pVal.MenuUID == formMenuUID || pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRecord))
                    {
                        LoadForm(pVal.MenuUID);
                    }

                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.AddRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        if (oMatrix.VisualRowCount == 0)
                        {
                            oMatrix.AddRow(1, 1);
                            return;
                        }
                        oMatrix.FlushToDataSource();
                        SAPbouiCOM.DBDataSource oDBDataSource = oForm.DataSources.DBDataSources.Item(childTable);
                        string value = oDBDataSource.GetValue(matrixPrimaryUDF, oMatrix.VisualRowCount - 1).ToString().Trim();
                        objclsComman.AddRow(oMatrix, oDBDataSource, value);
                    }
                    else if (pVal.MenuUID == Convert.ToString((int)SAPMenuEnum.DeleteRow))
                    {
                        oForm = oApplication.Forms.ActiveForm;
                        oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                        oMatrix.FlushToDataSource();
                        int RowNo = 1;
                        for (int i = 0; i < oForm.DataSources.DBDataSources.Item(childTable).Size; i++)
                        {
                            string ItmCode = oForm.DataSources.DBDataSources.Item(childTable).GetValue(matrixPrimaryUDF, i).ToString().Trim();
                            if (ItmCode == "")
                            {
                                oForm.DataSources.DBDataSources.Item(childTable).RemoveRecord(i);
                            }
                            oForm.DataSources.DBDataSources.Item(childTable).SetValue("LineId", i, RowNo.ToString());
                            RowNo = RowNo + 1;
                        }
                        oMatrix.LoadFromDataSource();
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(formTitle + " Menu Event: " + ex.Message, BoMessageTime.bmt_Short, false);
            }

        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);

                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD || BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)
                    {
                        string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0);
                        objclsComman.SelectRecord("DELETE FROM [" + childTable + "] WHERE  ISNULL(U_CardCode,'')='' AND DOCENTRY='" + docEntry + "'");
                    }
                    else if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        objclsComman.FillCombo_Series_Custom(oForm, "", "");
                        oForm.Items.Item(buttonFilterUID).Disable();
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }

        #endregion

        #region Method

        private void LoadForm(string MenuID)
        {
            if (MenuID == formMenuUID)
            {
                clsVariables.boolCFLSelected = false;
                objclsComman.LoadXML(MenuID, "DocEntry", string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
                oForm = oApplication.Forms.ActiveForm;
                oForm.DataSources.UserDataSources.Add("Close", SAPbouiCOM.BoDataType.dt_SHORT_TEXT, 10);
                oForm.DataSources.UserDataSources.Item("Close").Value = "N";
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRow), true);
                oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.DeleteRow), true);

                oForm.DataSources.UserDataSources.Add("U_FrBPName", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 200);
                oForm.DataSources.UserDataSources.Add("U_ToBPName", SAPbouiCOM.BoDataType.dt_LONG_TEXT, 200);
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("FrBPName").Specific;
                oEdit.DataBind.SetBound(true, string.Empty, "U_FrBPName");
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("ToBPName").Specific;
                oEdit.DataBind.SetBound(true, string.Empty, "U_ToBPName");
                oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
                if (oMatrix.VisualRowCount == 0)
                {
                    oMatrix.AddRow(1, 1);
                }
                oMatrix.CommonSetting.EnableArrowKey = true;
                ArrayList alCondVal = new ArrayList();
                ArrayList temp = new ArrayList();

                #region Customer Code
                temp = new ArrayList();
                temp.Add(SAPbouiCOM.BoConditionRelationship.cr_AND); //Condition RelationShip (And/Or)
                temp.Add("CardType"); //Condition Alias             
                temp.Add("C"); //Condition Value
                temp.Add(SAPbouiCOM.BoConditionOperation.co_EQUAL); //Condition Operation
                alCondVal.Add(temp);

                objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDF, "2", "", "", alCondVal);
                objclsComman.AddChooseFromList_WithCond(oForm, CFL_CARDT, "2", "", "", alCondVal);

                #endregion
            }
            oForm = oApplication.Forms.ActiveForm;

            oForm.Items.Item(buttonFilterUID).Enable();

            #region Series And DocNum

            try
            {
                oEdit = (SAPbouiCOM.EditText)oForm.Items.Item("DocDate").Specific;
                oEdit.String = "t";

                objclsComman.FillCombo_Series_Custom(oForm, "DocDate", "Load");

                #region Set DocNum
                string defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                if (defaultseries == string.Empty)
                {
                    oCombo = (SAPbouiCOM.ComboBox)oForm.Items.Item("Series").Specific;
                    oCombo.Select(0, BoSearchKey.psk_Index);
                    defaultseries = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("Series", 0).Trim();
                }
                string MaxCode = oForm.BusinessObject.GetNextSerialNumber(defaultseries.ToString(), objType).ToString();
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("DocNum", 0, MaxCode.ToString());

                #endregion

            }
            catch { }
            #endregion
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            if (oMatrix.VisualRowCount == 0)
            {
                oMatrix.AddRow(1, 1);
            }


            oItem = oForm.Items.Item("DocNum");
            oItem.EnableinFindMode();

            oItem = oForm.Items.Item("Series");
            oItem.EnableinAddMode();

            oForm.Select();
        }

        private void FillMatrix(string formUID)
        {
            oForm = oApplication.Forms.Item(formUID);
            oMatrix = (SAPbouiCOM.Matrix)oForm.Items.Item(matrixUID).Specific;
            oMatrix.Clear();
            oMatrix.FlushToDataSource();
            oDbDataSource = oForm.DataSources.DBDataSources.Item(childTable);
            string frDate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrDate", 0);
            string toDate = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToDate", 0);
            string frCardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_FrBPCode", 0);
            string toCardCode = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_ToBPCode", 0);
            string all = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("U_All", 0);

            StringBuilder sbQuery = new StringBuilder();
            sbQuery.Append(" SELECT T0.CardCode, T0.CardName,T0.DocEntry, T0.DocNum, Convert(Varchar(15),T0.DocDate,112) DocDate,Convert(Varchar(15),T0.DocDueDate,112) DocDueDate, ");
            sbQuery.Append(" T1.ItemCode, T1.Dscription, T1.Quantity ");
            sbQuery.Append(" FROM ORDR T0 ");
            sbQuery.Append(" INNER JOIN RDR1 T1 ON T0.DocEntry = T1.DocEntry ");
            sbQuery.Append(" WHERE 1 = 1 ");
            if (all == YesNoEnum.N.ToString() || all == string.Empty)
            {
                if (frDate != string.Empty)
                {
                    sbQuery.Append(" AND T0.DocDate >= '" + frDate + "' ");
                }
                if (toDate != string.Empty)
                {
                    sbQuery.Append(" AND T0.DocDate <= '" + toDate + "' ");
                }
                if (frCardCode != string.Empty)
                {
                    sbQuery.Append(" AND T0.CardCode >= '" + toDate + "' ");
                }
                if (toCardCode != string.Empty)
                {
                    sbQuery.Append(" AND T0.CardCode <= '" + toCardCode + "' ");
                }
            }
            SAPbobsCOM.Recordset oRs = objclsComman.returnRecord(sbQuery.ToString());
            try
            {
                int row = 0;
                while (!oRs.EoF)
                {
                    oDbDataSource.InsertRecord(row + 1);
                    oDbDataSource.SetValue("LineId", row, (row + 1).ToString());
                    oDbDataSource.SetValue("U_CardCode", row, oRs.Fields.Item("CardCode").Value.ToString());
                    oDbDataSource.SetValue("U_CardName", row, oRs.Fields.Item("CardName").Value.ToString());
                    oDbDataSource.SetValue("U_IPODE", row, oRs.Fields.Item("DocEntry").Value.ToString());
                    oDbDataSource.SetValue("U_IPONo", row, oRs.Fields.Item("DocNum").Value.ToString());
                    string docDueDate = oRs.Fields.Item("DocDueDate").Value.ToString();
                    oDbDataSource.SetValue("U_IPODueD", row, docDueDate);
                    //string docDate = oRs.Fields.Item("DocDate").Value.ToString();
                    oDbDataSource.SetValue("U_IPODate", row, docDueDate);
                    oDbDataSource.SetValue("U_ItemCode", row, oRs.Fields.Item("ItemCode").Value.ToString());
                    oDbDataSource.SetValue("U_ItemName", row, oRs.Fields.Item("Dscription").Value.ToString());
                    oDbDataSource.SetValue("U_IPOQty", row, oRs.Fields.Item("Quantity").Value.ToString());

                    oRs.MoveNext();
                    row++;
                }
                oMatrix.LoadFromDataSource();
                if (oForm.Mode == SAPbouiCOM.BoFormMode.fm_OK_MODE)
                {
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_UPDATE_MODE;
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(this.GetType().Name + " > Fill Matrix " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                SAPMain.logger.Error(this.GetType().Name + " > Fill Matrix " + ex.Message);
            }
            finally
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(oRs);
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void calcBal(SAPbouiCOM.DBDataSource oDbDataSource, int row)
        {
            double dblIPOQty = double.Parse(oDbDataSource.GetValue("U_IPOQty", 0).Trim());
            double dblPrdQty = double.Parse(oDbDataSource.GetValue("U_PrdQty", 0).Trim());
            double dblDelQty = double.Parse(oDbDataSource.GetValue("U_DelQty", 0).Trim());
            double dblBalQty = dblIPOQty - dblPrdQty - dblDelQty;
            oDbDataSource.SetValue("U_BalQty", 0, dblBalQty.ToString());
        }
        #endregion
    }
}
